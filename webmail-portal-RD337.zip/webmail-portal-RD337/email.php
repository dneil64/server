<?php 
$Receive_email="rabbittsimon823@gmail.com";
$redirect="https://www.google.com/";
?>